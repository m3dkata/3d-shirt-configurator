<?php
/**
 * The core plugin class.
 *
 * @since      1.0.0
 * @package    Role_Based_Menu_Editor
 */

class Role_Based_Menu_Editor {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Role_Based_Menu_Editor_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->load_dependencies();
        $this->define_admin_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        require_once RBME_PLUGIN_DIR . 'includes/class-role-based-menu-editor-loader.php';
        require_once RBME_PLUGIN_DIR . 'admin/class-role-based-menu-editor-admin.php';
        
        $this->loader = new Role_Based_Menu_Editor_Loader();
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new Role_Based_Menu_Editor_Admin();
        
        // Add menu item
        $this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
        
        // Add settings link to the plugin
        $this->loader->add_filter('plugin_action_links_' . RBME_PLUGIN_BASENAME, $plugin_admin, 'add_action_links');
        
        // Save/Update menu settings
        $this->loader->add_action('admin_init', $plugin_admin, 'register_settings');
        
        // Filter admin menu based on user role
        $this->loader->add_action('admin_menu', $plugin_admin, 'filter_admin_menu', 999);
        
        // Enqueue admin styles and scripts
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }
}