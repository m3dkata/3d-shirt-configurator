<?php
/**
 * Plugin Name: Role Based Menu Editor
 * Plugin URI: https://example.com/plugins/role-based-menu-editor
 * Description: A WordPress plugin that allows editing admin menu items per user role
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: role-based-menu-editor
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('RBME_VERSION', '1.0.0');
define('RBME_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RBME_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RBME_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include the core plugin class
require_once RBME_PLUGIN_DIR . 'includes/class-role-based-menu-editor.php';

// Begin execution of the plugin
function run_role_based_menu_editor() {
    $plugin = new Role_Based_Menu_Editor();
    $plugin->run();
}
run_role_based_menu_editor();