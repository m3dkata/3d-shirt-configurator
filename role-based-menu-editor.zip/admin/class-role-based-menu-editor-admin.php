<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Role_Based_Menu_Editor
 */

class Role_Based_Menu_Editor_Admin {

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Nothing to initialize yet
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles($hook) {
        // Only load on our settings page
        if ('settings_page_role-based-menu-editor' !== $hook) {
            return;
        }
        
        wp_enqueue_style('rbme-admin', RBME_PLUGIN_URL . 'admin/css/role-based-menu-editor-admin.css', array(), RBME_VERSION, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts($hook) {
        // Only load on our settings page
        if ('settings_page_role-based-menu-editor' !== $hook) {
            return;
        }
        
        wp_enqueue_script('rbme-admin', RBME_PLUGIN_URL . 'admin/js/role-based-menu-editor-admin.js', array('jquery'), RBME_VERSION, false);
    }

    /**
     * Add an options page under the Settings submenu
     *
     * @since  1.0.0
     */
    public function add_plugin_admin_menu() {
        add_options_page(
            __('Role Based Menu Editor Settings', 'role-based-menu-editor'),
            __('Menu Editor', 'role-based-menu-editor'),
            'manage_options',
            'role-based-menu-editor',
            array($this, 'display_plugin_setup_page')
        );
    }

    /**
     * Add settings action link to the plugins page.
     *
     * @since    1.0.0
     */
    public function add_action_links($links) {
        $settings_link = array(
            '<a href="' . admin_url('options-general.php?page=role-based-menu-editor') . '">' . __('Settings', 'role-based-menu-editor') . '</a>',
        );
        return array_merge($settings_link, $links);
    }

    /**
     * Register settings for the plugin
     *
     * @since    1.0.0
     */
    public function register_settings() {
        register_setting(
            'rbme_settings',
            'rbme_menu_settings',
            array($this, 'validate_settings')
        );
    }

    /**
     * Validate settings before saving
     *
     * @since    1.0.0
     */
    public function validate_settings($input) {
        // Sanitize the input
        if (isset($input) && is_array($input)) {
            foreach ($input as $role => $menu_items) {
                if (is_array($menu_items)) {
                    foreach ($menu_items as $menu_key => $status) {
                        $input[$role][$menu_key] = sanitize_text_field($status);
                    }
                }
            }
        }
        return $input;
    }

    /**
     * Render the settings page for this plugin.
     *
     * @since    1.0.0
     */
    public function display_plugin_setup_page() {
        include_once RBME_PLUGIN_DIR . 'admin/partials/role-based-menu-editor-admin-display.php';
    }

    /**
     * Filter admin menu based on user role
     *
     * @since    1.0.0
     */
    public function filter_admin_menu() {
        // Don't filter for administrators
        if (current_user_can('administrator')) {
            return;
        }

        $current_user = wp_get_current_user();
        $user_roles = $current_user->roles;
        $current_role = reset($user_roles); // Get the first role
        
        $menu_settings = get_option('rbme_menu_settings', array());
        
        if (isset($menu_settings[$current_role]) && is_array($menu_settings[$current_role])) {
            global $menu, $submenu;
            
            // Filter top-level menu items
            foreach ($menu as $menu_key => $menu_item) {
                $menu_slug = $menu_item[2];
                
                // If this menu item is set to be hidden for this role
                if (isset($menu_settings[$current_role][$menu_slug]) && $menu_settings[$current_role][$menu_slug] === 'hidden') {
                    unset($menu[$menu_key]);
                }
            }
            
            // Filter submenu items
            if (is_array($submenu)) {
                foreach ($submenu as $parent_slug => $submenu_items) {
                    foreach ($submenu_items as $submenu_key => $submenu_item) {
                        $submenu_slug = $submenu_item[2];
                        $full_submenu_slug = $parent_slug . ':' . $submenu_slug;
                        
                        // If this submenu item is set to be hidden for this role
                        if (isset($menu_settings[$current_role][$full_submenu_slug]) && $menu_settings[$current_role][$full_submenu_slug] === 'hidden') {
                            unset($submenu[$parent_slug][$submenu_key]);
                        }
                    }
                    
                    // If all submenu items are removed, remove the parent menu too
                    if (empty($submenu[$parent_slug])) {
                        foreach ($menu as $menu_key => $menu_item) {
                            if ($menu_item[2] == $parent_slug) {
                                unset($menu[$menu_key]);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Get all available WordPress roles
     *
     * @since    1.0.0
     * @return   array    Array of role objects
     */
    public function get_roles() {
        global $wp_roles;
        if (!isset($wp_roles)) {
            $wp_roles = new WP_Roles();
        }
        return $wp_roles->roles;
    }

    /**
     * Get the current admin menu structure
     *
     * @since    1.0.0
     * @return   array    Array of menu items
     */
    public function get_admin_menu() {
        global $menu, $submenu;
        
        // We need to ensure the admin menu is loaded
        if (empty($menu)) {
            require_once(ABSPATH . 'wp-admin/includes/admin.php');
            require_once(ABSPATH . 'wp-admin/menu.php');
        }
        
        return array(
            'menu' => $menu,
            'submenu' => $submenu
        );
    }
}