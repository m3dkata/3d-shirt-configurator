/**
 * Admin JavaScript for Role Based Menu Editor
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Toggle all submenu items when parent menu is toggled
        $('.top-level-menu input[type="radio"]').on('change', function() {
            var isHidden = $(this).val() === 'hidden';
            var $row = $(this).closest('tr');
            var $submenus = $row.nextUntil('.top-level-menu');
            
            if (isHidden) {
                // If parent menu is hidden, hide all submenu items
                $submenus.find('input[value="hidden"]').prop('checked', true);
            }
        });
    });

})(jQuery);