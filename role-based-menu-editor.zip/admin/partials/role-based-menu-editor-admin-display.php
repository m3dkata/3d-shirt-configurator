<?php
/**
 * Provide a admin area view for the plugin
 *
 * @since      1.0.0
 * @package    Role_Based_Menu_Editor
 */

// Get the admin instance
$admin = new Role_Based_Menu_Editor_Admin();

// Get all roles
$roles = $admin->get_roles();

// Get saved settings
$menu_settings = get_option('rbme_menu_settings', array());

// Get current admin menu
$admin_menu = $admin->get_admin_menu();
$menu_items = $admin_menu['menu'];
$submenu_items = $admin_menu['submenu'];

// Current selected role
$current_role = isset($_GET['role']) ? sanitize_text_field($_GET['role']) : 'administrator';
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <h2 class="nav-tab-wrapper">
        <?php foreach ($roles as $role_key => $role) : ?>
            <a href="?page=role-based-menu-editor&role=<?php echo esc_attr($role_key); ?>" class="nav-tab <?php echo ($current_role === $role_key) ? 'nav-tab-active' : ''; ?>">
                <?php echo esc_html($role['name']); ?>
            </a>
        <?php endforeach; ?>
    </h2>
    
    <form method="post" action="options.php">
        <?php settings_fields('rbme_settings'); ?>
        
        <p><?php _e('Configure which admin menu items should be visible for each user role.', 'role-based-menu-editor'); ?></p>
        
        <table class="widefat rbme-menu-table">
            <thead>
                <tr>
                    <th><?php _e('Menu Item', 'role-based-menu-editor'); ?></th>
                    <th><?php _e('Visibility', 'role-based-menu-editor'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($menu_items)) : ?>
                    <?php foreach ($menu_items as $menu_item) : ?>
                        <?php
                        // Skip separators
                        if (empty($menu_item[0]) || $menu_item[0] == '') {
                            continue;
                        }
                        
                        $menu_title = strip_tags($menu_item[0]);
                        $menu_slug = $menu_item[2];
                        $is_visible = !isset($menu_settings[$current_role][$menu_slug]) || $menu_settings[$current_role][$menu_slug] !== 'hidden';
                        ?>
                        <tr class="top-level-menu">
                            <td><strong><?php echo esc_html($menu_title); ?></strong></td>
                            <td>
                                <label>
                                    <input type="radio" name="rbme_menu_settings[<?php echo esc_attr($current_role); ?>][<?php echo esc_attr($menu_slug); ?>]" value="visible" <?php checked($is_visible, true); ?>>
                                    <?php _e('Visible', 'role-based-menu-editor'); ?>
                                </label>
                                <label>
                                    <input type="radio" name="rbme_menu_settings[<?php echo esc_attr($current_role); ?>][<?php echo esc_attr($menu_slug); ?>]" value="hidden" <?php checked($is_visible, false); ?>>
                                    <?php _e('Hidden', 'role-based-menu-editor'); ?>
                                </label>
                            </td>
                        </tr>
                        
                        <?php if (isset($submenu_items[$menu_slug])) : ?>
                            <?php foreach ($submenu_items[$menu_slug] as $submenu_item) : ?>
                                <?php
                                $submenu_title = strip_tags($submenu_item[0]);
                                $submenu_slug = $submenu_item[2];
                                $full_submenu_slug = $menu_slug . ':' . $submenu_slug;
                                $is_submenu_visible = !isset($menu_settings[$current_role][$full_submenu_slug]) || $menu_settings[$current_role][$full_submenu_slug] !== 'hidden';
                                ?>
                                <tr class="sub-menu">
                                    <td>&nbsp;&nbsp;&nbsp;— <?php echo esc_html($submenu_title); ?></td>
                                    <td>
                                        <label>
                                            <input type="radio" name="rbme_menu_settings[<?php echo esc_attr($current_role); ?>][<?php echo esc_attr($full_submenu_slug); ?>]" value="visible" <?php checked($is_submenu_visible, true); ?>>
                                            <?php _e('Visible', 'role-based-menu-editor'); ?>
                                        </label>
                                        <label>
                                            <input type="radio" name="rbme_menu_settings[<?php echo esc_attr($current_role); ?>][<?php echo esc_attr($full_submenu_slug); ?>]" value="hidden" <?php checked($is_submenu_visible, false); ?>>
                                            <?php _e('Hidden', 'role-based-menu-editor'); ?>
                                        </label>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="2"><?php _e('No menu items found.', 'role-based-menu-editor'); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php submit_button(__('Save Settings', 'role-based-menu-editor')); ?>
    </form>
</div>